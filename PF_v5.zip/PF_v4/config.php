<?php
$usuario  = "root";
$password = "";
$servidor = "localhost";
$basededatos = "proyecto";


$con = mysqli_connect($servidor, $usuario, $password) or die("Error al conectar con el servidor");
$db = mysqli_select_db($con, $basededatos) or die("Error al conectar DB");

$conn = new mysqli("localhost","root","","proyecto");

define("HOST","localhost");
define("USER","root");
define("PASS","");
define("DB","proyecto");

//conexion
function conexionDB(){
	$link = new mysqli(HOST,USER,PASS,DB);
	if($link->connect_error){
		//print("error");
		$error= "Error en la conexión".$link->connect_errno." mensaje: ".$link->connect_error;
		die($error); 
	}
	//print("conectado");
	$consultaSQL= "SET CHARACTER SET UTF8";
	$link->query($consultaSQL);	
	return $link;
} 
?>

