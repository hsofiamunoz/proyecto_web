<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>MedNET</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/apple-touch-icon.PNG" rel="icon">
  <link href="assets/img/apple-touch-icon.PNG" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Roboto:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: BizLand - v3.7.0
  * Template URL: https://bootstrapmade.com/bizland-bootstrap-business-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>
  <!-- ======= Header ======= --> 
  <header id="header" class="d-flex align-items-center">
    <div class="container d-flex align-items-center justify-content-between">

      <h1 class="logo"><a href="index.php"><img src="assets/img/logo.PNG" alt=""></a></h1>

      <nav id="navbar" class="navbar"> <!-- ======= Barra navegador ======= --> 
        <ul>
          <li><a class="nav-link scrollto active" href="#hero">Inicio</a></li>
          <li><a class="nav-link scrollto" href="#about">¿Quienes somos?</a></li>
          <li><a class="nav-link scrollto" href="#services">Nuestro trabajo</a></li>
          <li><a class="nav-link scrollto " href="#portfolio">¿Cómo funciona?</a></li>
          <li><a class="nav-link scrollto" href="calendario_visual.php">Eventos</a></li>
          <li><a class="nav-link scrollto" href="mapa.php">Mapa</a></li>
          <li><a class="nav-link scrollto" href="log_in_emp.php">Login</a></li>
          <li class="dropdown"><a href="#"><span>Registro</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="registro_emp.php">Empresa</a></li>
              <li><a href="registro_voluntario.php">Voluntario</a></li>
            </ul>
          </li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->
    </div>
  </header><!-- End Header -->

  <!-- ======= Contenedor de inicio de la página ======= -->
  <section id="hero" class="d-flex align-items-center" >
    <div class="container" data-aos="zoom-out" data-aos-delay="100" style="min: height 600px;">
      <h1 style="color: rgb(87, 85, 85);">Bienvenido a <span>MedNET</span></h1>
      <h2>Somos una comunidad con el objetivo de ayudar a las fundaciones de la ciudad.</h2>
      <div class="d-flex">
        <a href="#about" class="btn-get-started scrollto">Aprende sobre nosotros</a><!-- 
          <a href="https://www.youtube.com/watch?v=jDDaplaOz7Q" class="glightbox btn-watch-video"><i class="bi bi-play-circle"></i><span>Watch Video</span></a>
         --></div>
    </div>
  </section><!-- End Hero -->

  <main id="main"> <!-- ======= Información general de la página ======= --> 

    <!-- ======= About Section ======= -->
    <section id="about" class="about section-bg">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>¿Quienes somos?</h2>
          <h3>Queremos conectar aquellos que necesitan ayuda con quienes están dispuestos a ayudar</h3>
        </div>

        <div class="row">
          <div class="col-lg-6" data-aos="fade-right" data-aos-delay="100">
            <img src="assets/img/somos.jpg" class="img-fluid" alt="">
          </div>
          <div class="col-lg-6 pt-4 pt-lg-0 content d-flex flex-column justify-content-center" data-aos="fade-up" data-aos-delay="100">
            <p style="color: aliceblue; font-style: italic;"> En una ciudad tan grande como Medellín hay muchas fundaciones y empresas que realizan obras de caridad, donatones y eventos para la comunidad
              sin ebmbargo no todas las personas se enteran de estos eventos debido a las redes se encuentran saturadas con 
              otro tipo de información, por esto nace la iniciativa de crea una página que integre a las fundaciónes con el proósito de divultar sus proyectos.</p>
            <ul>
              <li>               
                <div>
                  <h5>Misión</h5>
                  <p>Ser un canal efectivo de comunicación entre las empresas y fundaciones de Medellín y los ciudadanos para 
                    para una excelente realización de eventos, donatones y otros.
                  </p>
                </div>
              </li>
              <li>                
                <div>
                  <h5>Objetivos</h5>
                  <p>Brindar información clara y específica a los usuarios sobre las fundaciones, cómo se puede contribuir, cuales son los canales de comunicación y otros.</p>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </section><!-- End About Section -->

    <!-- ======= Información general de los trabajos realizados ======= -->
    <section id="services" class="services">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Nuestro trabajo</h2>
          <h3>Te contamos nuestro <span> progreso</span></h3>
          <p> Estos son nuestros logros hasta el momento, adicionalmente de las organizaciones con las que hemos trabajado</p>
        </div>

    <!-- ======= Counts Section ======= -->
    <section id="counts" class="counts">
      <div class="container" data-aos="fade-up">

        <div class="row">
          <div class="col-lg-3 col-md-6">
            <div class="count-box">
              <i class="bi bi-emoji-smile"></i>
              <span data-purecounter-start="0" data-purecounter-end="232" data-purecounter-duration="1" class="purecounter"></span>
              <p>Empresas afiliadas</p>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 mt-5 mt-md-0">
            <div class="count-box">
              <i class="bi bi-journal-richtext"></i>
              <span data-purecounter-start="0" data-purecounter-end="521" data-purecounter-duration="1" class="purecounter"></span>
              <p>Eventos programados</p>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 mt-5 mt-lg-0">
            <div class="count-box">
              <i class="bi bi-headset"></i>
              <span data-purecounter-start="0" data-purecounter-end="1463" data-purecounter-duration="1" class="purecounter"></span>
              <p>Nuevas conexiones</p>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 mt-5 mt-lg-0">
            <div class="count-box">
              <i class="bi bi-people"></i>
              <span data-purecounter-start="0" data-purecounter-end="15" data-purecounter-duration="1" class="purecounter"></span>
              <p>Voluntariados</p>
            </div>
          </div>
        </div>
      </div>
    </section><!-- End Counts Section -->

    <!-- ======= Clients Section ======= -->
    <section id="clients" class="clients section-bg">
      <div class="container" data-aos="zoom-in">

        <div class="row">

          <div class="col-lg-2 col-md-4 col-6 d-flex align-items-center justify-content-center">
            <img src="assets/img/clients/alcaldia.jpg" class="img-fluid" alt="">
          </div>

          <div class="col-lg-2 col-md-4 col-6 d-flex align-items-center justify-content-center">
            <img src="assets/img/clients/puentes.png" class="img-fluid" alt="">
          </div>

          <div class="col-lg-2 col-md-4 col-6 d-flex align-items-center justify-content-center">
            <img src="assets/img/clients/huellas.png" class="img-fluid" alt="">
          </div>

          <div class="col-lg-2 col-md-4 col-6 d-flex align-items-center justify-content-center">
            <img src="assets/img/clients/eco.png" class="img-fluid" alt="">
          </div>

          <div class="col-lg-2 col-md-4 col-6 d-flex align-items-center justify-content-center">
            <img src="assets/img/clients/orca.png" class="img-fluid" alt="">
          </div>

          <div class="col-lg-2 col-md-4 col-6 d-flex align-items-center justify-content-center">
            <img src="assets/img/clients/lupines.jpg" class="img-fluid" alt="">
          </div>

        </div>
      </div>
    </section><!-- End Clients Section -->        

      </div>
    </section><!-- End Services Section -->

    <!-- ======= Portfolio Section ======= -->
    <section id="portfolio" class="portfolio">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>¿Que puedes hacer?</h2>
          <h3>Formas de <span> conectarte</span></h3>
          <p>Debido a las diferentes redes sociales es dificil encontrar información clara y actual de diferentes fundaciones, a través de esta página te pueden enterar de los eventos que organizar las empresas y organizaciones inscritas,
            donde se publicarán por categorías las convocatorias de voluntariados, donatones y eventos. No es necesario crear una cuenta de usuario pero si quieres mantenerte actualizado sobre los eventos de una fundación en especial debes registrarte</p>
        </div>

        <div class="row" data-aos="fade-up" data-aos-delay="100">
          <div class="col-lg-12 d-flex justify-content-center">
            <ul id="portfolio-flters">
              <!-- <li data-filter="*" class="filter-active">All</li> -->
              <li data-filter=".filter-app">Voluntariados</li>
              <li data-filter=".filter-card">Donatones</li>
              <li data-filter=".filter-web"><a href="calendario.php" class="details-link" title="More Details"><i class="bx bx-link"></i>Eventos</a></li>
            </ul>
          </div>
        </div>

        <div class="row portfolio-container" data-aos="fade-up" data-aos-delay="200">

          <div class="col-lg-4 col-md-6 portfolio-item filter-app">
            <img src="assets/img/portfolio/v1.jpg" class="img-fluid" alt="">
            <div class="portfolio-info">
              <p>Más información</p>
              <a href="https://ssvpaulmedellin.org/ser-voluntario/" class="details-link" title="More Details"><i class="bx bx-link"></i></a>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-app">
            <img src="assets/img/portfolio/v3.jpg" class="img-fluid" alt="">
            <div class="portfolio-info">
              <p>Más información</p>
              <a href="https://fundacionpoderjoven.org/" class="details-link" title="More Details"><i class="bx bx-link"></i></a>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-app">
            <img src="assets/img/portfolio/v2.jpg" class="img-fluid" alt="">
            <div class="portfolio-info">
              <p>Más información</p>
              <a href="https://www.crantioquia.org.co/Voluntariado/ComoSerVoluntario" class="details-link" title="More Details"><i class="bx bx-link"></i></a>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-app">
            <img src="assets/img/portfolio/v4.jpg" class="img-fluid" alt="">
            <div class="portfolio-info">
              <p>Más información</p>
              <a href="https://bancodealimentos.co/site/voluntariado/" class="details-link" title="More Details"><i class="bx bx-link"></i></a>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-card">
            <img src="assets/img/portfolio/d11.jpg" class="img-fluid" alt="">
            <div class="portfolio-info">
              <p>Más información</p>
              <a href="https://udea.edu.co/wps/portal/udea/web/generales/interna/!ut/p/z1/tVhde6I4FP4rnYteZjnkA8IlsqxK_QCt05EbnxCCZVelo7Qz018_sbs7rdaK82i8gYMn73nPy0lOgpVaX6x0JZ7KuajLaiUW2p6mzox7AbZ9Cr32KArAdwI_dMefe5hj627XAW5sBn4SxoPbYRD_GWErPWU8fPDz4bTxg4SFNg50_HHXgQQPB2HgDMb-LX0Z_-vvYYf_BQmM-q12EtohZdZnK7VSuaof6ntr-lCta7F4zJW4BrHZte6rpfr3Xn2v1Wqj9dk-ltVKW2VebbbWotzUIq-uoX5caGuhVmKzDfAgy9yaQgYEHEyQkiARtQVFGWQcyZxyzHO7yLg6nFA3jjqR4w47xN5N6H2-e-PfZ5z-1gt975Aef19323wbGOxy4KAd_OS2F9JJH2D4zuFAUTWxSJtk2ifZJSEk3oDFpN3F1CX7HHZ1uImxNdVCuR-GIFrJp1J9syarar3UM2n8pg6k8FwPS8RVgXUdyAJlOXUREOEA4a5XuNLqQFMEcmaE4_ARmIXHZuGZWXjXKHyLmoW3D8HfBf1Z3LWm9tZYbWZHAWYv3mv1VFaPm1jM1bh8Vn8wzxbEcwBlNtfcmMxQxvR65zCHSKBEYuDWlMHpETTyiaj2ZSU69wVHTQuQ7qzl31-_pr5uP9se8r22vvx2_3lxKapFWV1tKllqngfT-tU-js26nGWSSrdAQHMXUQ848iQpEKc4zxSRvMhUEzwzCn9sWlwC3jEJH8fEKPsRmIU3Wzkj2yy8axTePZf9wdXi7abPzGpxDW-3r6_36NVTj1oLWZdSbK7QlZAiV8utsWWE1_2gP9eJivoelaui0pwOO-_Jx_t606eNfuKxzpDBhef1Lnzcsi_bTfc2tDdH4KW0ZQY51uwpRVQ5FHFMFaLcBsZkzjxPNMAHcFl4PkoYJJ0O93Uo18GuSfgkIibFmXiOWe2JUe27F66cnbqn0ZgZFQefW5hR0znxAovefzl8dJwdHlsaTjmtH4encBH4V4kA61PqsBW1e30bhgE2y96sODfnso-aPmVcpGme9InnYTmZTJac_ChL9M8oHHWeWwPUDjL-7bZY7l-eVfb8Yv4gW7dp9HT00lN3jT7_uxb9kLD5cvbmspj7nz79BBiEVDA!/" class="details-link" title="More Details"><i class="bx bx-link"></i></a>
            </div>
          </div>                  

          <div class="col-lg-4 col-md-6 portfolio-item filter-card">
            <img src="assets/img/portfolio/d2.jpg" class="img-fluid" alt="">
            <div class="portfolio-info">
              <p>Más información</p>
              <a href="https://fundacionorca.org/pagina/6/donaciones" class="details-link" title="More Details"><i class="bx bx-link"></i></a>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-card">
            <img src="assets/img/portfolio/d33.PNG" class="img-fluid" alt="">
            <div class="portfolio-info">
              <p>Más información</p>
              <a href="https://www.medellin.edu.co/donaton-tecnologica/" class="details-link" title="More Details"><i class="bx bx-link"></i></a>
            </div>
          </div>

        </div>
      </div>
    </section><!-- End Portfolio Section -->

    <!-- ======= Frequently Asked Questions Section ======= -->
    <section id="faq" class="faq section-bg">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>F.A.Q</h2>
          <h3><span>Preguntas frecuentes</span></h3>
          </div>

        <div class="row justify-content-center">
          <div class="col-xl-10">
            <ul class="faq-list">

              <li>
                <div data-bs-toggle="collapse" class="collapsed question" href="#faq1">¿Puedo contactar personalmente la organización para contribuir? <i class="bi bi-chevron-down icon-show"></i><i class="bi bi-chevron-up icon-close"></i></div>
                <div id="faq1" class="collapse" data-bs-parent=".faq-list">
                  <p>
                    Claro que si, por esto en la sección de las organizaciones se encuentran todos los datos de contactos para facilitar tu conexión con la fundación que te interesa y se realizan actualizaciones regulares.
                  </p>
                </div>
              </li>

              <li>
                <div data-bs-toggle="collapse" href="#faq2" class="collapsed question">¿Como hago para que me llegue la información de los voluntariados a mi correo? <i class="bi bi-chevron-down icon-show"></i><i class="bi bi-chevron-up icon-close"></i></div>
                <div id="faq2" class="collapse" data-bs-parent=".faq-list">
                  <p>
                    Crea una cuenta de usuario y selecciona las fundaciones de las cuales quieres recibir noticias.</p>
                </div>
              </li>

              <li>
                <div data-bs-toggle="collapse" href="#faq3" class="collapsed question">¿Como puedo participar de esta página como fundación y divulgar mis datos? <i class="bi bi-chevron-down icon-show"></i><i class="bi bi-chevron-up icon-close"></i></div>
                <div id="faq3" class="collapse" data-bs-parent=".faq-list">
                  <p>
                    Ingresa a registro y crea una cuenta de organización, donde podrás añadir tus eventos y acciones para el público.
                  </p>
                </div>
              </li>              

            </ul>
          </div>
        </div>

      </div>
    </section><!-- End Frequently Asked Questions Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer">

    <div class="footer-newsletter">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-lg-6">
            <h4>Recibe boletín semanal de los eventos</h4>
            <p>Ingresa tu correo electrónico y prográmate</p>
            <form action="" method="post">
              <input type="email" name="email"><input type="submit" value="Subscribete">
            </form>
          </div>
        </div>
      </div>
    </div>

    <div class="container py-4">
      <div class="copyright">
        &copy; Copyright <strong><span>MedNET</span></strong>. All Rights Reserved
      </div>
      <div class="credits">
        <!-- All the links in the footer should remain intact. -->
        <!-- You can delete the links only if you purchased the pro version. -->
        <!-- Licensing information: https://bootstrapmade.com/license/ -->
        <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/bizland-bootstrap-business-template/ -->
        Diseñado por <a href="https://bootstrapmade.com/">BootstrapMade</a> junto con Helena Muñoz e Isabella Bermón
      </div>
    </div>
  </footer><!-- End Footer -->

  <div id="preloader"></div>
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/purecounter/purecounter.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/waypoints/noframework.waypoints.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>