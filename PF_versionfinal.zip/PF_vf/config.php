<?php

// Codigos base de datos PROYECTO

define("HOST","localhost");
define("USER","root");
define("PASS","");
define("DB","proyecto");

$con = mysqli_connect(HOST, USER, PASS) or die("Error al conectar con el servidor");
$db = mysqli_select_db($con, DB) or die("Error al conectar DB");

//conexion
function conexionDB(){
	$link = new mysqli(HOST,USER,PASS,DB);
	if($link->connect_error){
		//print("error");
		$error= "Error en la conexión".$link->connect_errno." mensaje: ".$link->connect_error;
		die($error); 
	}
	//print("conectado");
	$consultaSQL= "SET CHARACTER SET UTF8";
	$link->query($consultaSQL);	
	return $link;
} 
?>

