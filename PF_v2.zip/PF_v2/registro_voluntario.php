<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>MedNET</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/apple-touch-icon.PNG" rel="icon">
  <link href="assets/img/apple-touch-icon.PNG" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Roboto:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: BizLand - v3.7.0
  * Template URL: https://bootstrapmade.com/bizland-bootstrap-business-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

    <!-- ======= Header ======= -->
    <header id="header" class="d-flex align-items-center">
      <div class="container d-flex align-items-center justify-content-between">  
        <h1 class="logo"><a href="index.html"><img src="img/logo.PNG" alt=""></a></h1>  
        <nav id="navbar" class="navbar">
          <ul>
            <li><a class="nav-link scrollto active" href="index.php">Inicio</a></li>
            <li><a class="nav-link scrollto" href="#about">¿Quienes somos?</a></li>
            <li><a class="nav-link scrollto" href="#services">Nuestro trabajo</a></li>
            <li><a class="nav-link scrollto " href="#portfolio">¿Cómo funciona?</a></li>
            <li><a class="nav-link scrollto" href="calendario.php">Eventos</a></li>
            <li><a class="nav-link scrollto" href="mapa.html">Mapa</a></li>
            <li><a class="nav-link scrollto" href="log_in.php">Login</a></li>
            <li class="dropdown"><a href="#"><span>Registro</span> <i class="bi bi-chevron-down"></i></a>
              <ul>
                <li><a href="log_in_emp.html">Empresa</a></li>
                <li><a href="registro_voluntario.php">Voluntario</a></li>
              </ul>
            </li>
          </ul>
          <i class="bi bi-list mobile-nav-toggle"></i>
        </nav><!-- .navbar -->
  
      </div>
    </header><!-- End Header -->

    <div style="height: 5px;"></div>

    <div class="login-forma" style="height: 600px;">
      <center><h1 style="color: black; font-weight: 400; font-family: calibri; ">REGISTRATE COMO VOLUNTARIO</h1></center><br>
      <form action="<?php echo $_SERVER['PHP_SELF'];?>" method="POST" enctype="multipart/form-data">
          <div class="mb-3  forma-grupo" style="width: 60%;">
             <label style="color: black; font-weight: 100; font-family: calibri; ">Nombre completo</label>
             <input name="nombre_usuario" placeholder="nombre apellido" type="name" class="form-control" required>
          </div>

          <div class=" mb-3 forma-grupo" style="width: 60%;">
             <label style="color: black; font-weight: 100; font-family: calibri; ">Correo electrónico</label>
					   <input name="correo_usuario" type="email" class="form-control" id="ejemplo123@gmail.com" placeholder="Ingrese correo electrónico"aria-describedby="emailHelp"required>	    			
				  </div>

				  <div class="mb-3 forma-grupo" style="width: 60%;">
				   	<label style="color: black; font-weight: 100; font-family: calibri; ">Contraseña</label>
				   	<input  name="contraseña_usuario" placeholder="*****" type="password" class="form-control" id="exampleInputPassword1" required>
				  </div>

          <div class="mb-3 forma-grupo" style="width: 60%;">
            <label style="color: black; font-weight: 100; font-family: calibri; ">Teléfono</label>
            <input  name="telefono_usuario" placeholder="3128271928" type="number" class="form-control" id="exampleInputPassword1" required>
          </div>

          <div class=" mb-3 forma-grupo" style="width: 60%;">
             <label style="color: black; font-weight: 100; font-family: calibri; ">Edad</label>
             <input name="edad_usuario" type="number" class="form-control" id="22" placeholder="Ingrese su edad" required>             
          </div>
          <br>
          <div class="forma-grupo1">         
            <button  type="submit" name="btn-register" class="btn btn-dark boton_registro" >Registrarse</button>
          </div>

		</form><br>
    </div>

    <?php 
		
    require_once "config.php";
		$link= conexionDB();
		if(isset($_REQUEST['btn-register'])){ 

				$consultaSQL="SELECT * FROM voluntarios WHERE correo_usuario='".$_POST['correo_usuario']."'";
				if($resultado= $link->query($consultaSQL)){
					//print("Consulta realizada"."<br>");
					//obtuvimos resultados??
					if (mysqli_num_rows($resultado)!=0) {
						echo "<script>alert('Usuario ya existe');</script>";
						//header("refresh:0.01; Location:index.php");

					}
					else{
						$consultaSQL= "INSERT INTO voluntarios (nombre_usuario, correo_usuario, contraseña_usuario, telefono_usuario, edad_usuario) VALUE ("
							."'".$_POST['nombre_usuario']."',"
              ."'".$_POST['correo_usuario']."',"
							."'".$_POST['contraseña_usuario']."',"
              ."'".$_POST['telefono_usuario']."',"
              ."'".$_POST['edad_usuario']."'"
							.")";

						 echo "<script>alert('Usuario registrado exitosamente');</script>";
						 //header("refresh:0.01; index.php");
             header("Location: index.php");

						$link->query($consultaSQL);
						$link->close();
					}
				}
		}
	
	?> -->

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>