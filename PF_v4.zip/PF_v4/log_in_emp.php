<?php
ob_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>MedNET</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/apple-touch-icon.PNG" rel="icon">
  <link href="assets/img/apple-touch-icon.PNG" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Roboto:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: BizLand - v3.7.0
  * Template URL: https://bootstrapmade.com/bizland-bootstrap-business-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>
    <!-- ======= Header ======= -->
    <header id="header" class="d-flex align-items-center">
      <div class="container d-flex align-items-center justify-content-between">  
      <h1 class="logo"><a href="index.php"><img src="assets/img/logo.PNG" alt=""></a></h1>
        <nav id="navbar" class="navbar">
          <ul>
            <li><a class="nav-link scrollto active" href="index.php">Inicio</a></li>
            <li><a class="nav-link scrollto" href="calendario.php">Eventos</a></li>            
            <li><a class="nav-link scrollto" href="mapa.php">Mapa</a></li>
            <li><a class="nav-link scrollto" href="log_in_emp.php">Login</a></li>
            <li class="dropdown"><a href="#"><span>Registro</span> <i class="bi bi-chevron-down"></i></a>
              <ul>
                <li><a href="registro_emp.php">Empresa</a></li>
                <li><a href="registro_voluntario.php">Voluntario</a></li>
              </ul>
            </li>
          </ul>
          <i class="bi bi-list mobile-nav-toggle"></i>
        </nav><!-- .navbar -->
  
      </div>
    </header><!-- End Header -->

    <div style="height: 20px;"></div>

    <div class="login-forma">
      <br>
      <center><h1 style="color: black; font-weight: 400; font-family: calibri; ">INICIAR SESIÓN</h1></center><br>
      <form action="<?php echo $_SERVER['PHP_SELF'];?>" method="post">

        <div class="forma-grupo" style="margin: left 50px;">
          <h2 style="color: black; font-weight: 100;  font-family: calibri; ">Correo electrónico:</h2>
        <div class="col-sm-12" style="width: 60%;">
          <input type="text" name="correo_usuario" class="form-control" placeholder="medNET@gmail.com" />
        </div>
        </div><br>
  
        <div class="forma-grupo">
          <h2 style="color: black; font-weight: 100;  font-family: calibri; ">Contraseña:</h2>
        <div class="col-sm-12" style="width: 60%;">
          <input type="password" name="contraseña_usuario" class="form-control" placeholder="1234fff" />
        </div><br>
  
        <div class="forma-grupo1">
          <input type="submit" name="btn-login" class="btn btn-dark btn-block" value="Iniciar sesión">        
        </div><br>  
        <!-- AQUI LLEVA A LA PÁGINA LOG_IN.HTML QUE ES DONDE SE PONE EL CALENDARIO CON OPCIONES DE EDITAR  -->
  
        <div class="forma-grupo2">
          ¿No te has registrado? Crea una cuenta de <a class="hola" href="registro_voluntario.php" style="color: aliceblue; font-weight: bold; "> Usuario</a> |          
          <a class="hola" href="registro_emp.php" style="color: aliceblue; font-weight: bold; "> Empresa</a>                    
        </div>
  
      </form>
    </div>

  <?php
    require_once "config.php";
    $link = conexionDB();
    $flag = 0;
		
    if(isset($_REQUEST['btn-login'])){

			$consultaSQL="SELECT * FROM voluntarios WHERE correo_usuario='".$_POST['correo_usuario']."' AND contraseña_usuario='".$_POST['contraseña_usuario']."'";

      if($resultado = $link->query($consultaSQL)){

				if (mysqli_num_rows($resultado)!=0) {
					$row = $resultado-> fetch_assoc();

          session_start();

					$_SESSION['id'] = $row['id'];
					$_SESSION['nombre_usuario'] = $row['nombre_usuario'];
					$_SESSION['contraseña_usuario'] = $row['contraseña_usuario'];
					header("Location: calendario_visual.php"); 
            // LLEVAR A EDITOR si de tabla de empresas header("Location: calendario.php"); 
            // LLEVAR A VISUAL si de tabla de voluntario header("Location: calendario_visual.php"); 
						
					}
				else{
           $consultaSQL="SELECT * FROM empresas WHERE correo_usuario='".$_POST['correo_usuario']."' AND contraseña_usuario='".$_POST['contraseña_usuario']."'";

           if ($resultado = $link->query($consultaSQL)) {

            if (mysqli_num_rows($resultado)!=0) {
              $row = $resultado-> fetch_assoc();

              session_start();

              $_SESSION['id'] = $row['id'];
              $_SESSION['correo_usuario'] = $row['correo_usuario'];
              $_SESSION['contraseña_usuario'] = $row['contraseña_usuario'];

              header("Location: calendario.php"); 
                // LLEVAR A EDITOR si de tabla de empresas header("Location: calendario.php"); 
                // LLEVAR A VISUAL si de tabla de voluntario header("Location: calendario_visual.php"); 
              }


            else{
              $consultaSQL="SELECT * FROM empresas WHERE correo_usuario='".$_POST['correo_usuario']."'";
              if ($resultado= $link->query($consultaSQL)) {
                if (mysqli_num_rows($resultado)==0) {
                  echo "<script>alert('Usuario no existe');</script>";
                  //header("refresh:0.01; registro.php");
                }
                else{
                  echo "<script>alert('Usuario o contraseña incorrectas');</script>";
                }
              }           
              
              $link->query($consultaSQL);
              $link->close();
            }
          }

				}
			}
		}
	
	?>
  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>

<?php
ob_end_flush();
?>