<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>MedNET</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- LINKS CALENDARIO -->
  <link rel="stylesheet" type="text/css" href="css/fullcalendar.min.css">
  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/icon?family=Material+Icons">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  <link href="assets/css/style.css" rel="stylesheet">


  <!-- =======================================================
  * Template Name: BizLand - v3.7.0
  * Template URL: https://bootstrapmade.com/bizland-bootstrap-business-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>
  <!-- ======= Header ======= -->
  <header id="header" class="d-flex align-items-center">
    <div class="container d-flex align-items-center justify-content-between">

    <h1 class="logo"><a href="index.php"><img src="assets/img/logo.PNG" alt=""></a></h1>
      <!-- Uncomment below if you prefer to use an image logo -->
      <!-- <a href="index.html" class="logo"><img src="assets/img/logo.png" alt=""></a>-->

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto active" href="index.php">Inicio</a></li>
          <!--<li><a class="nav-link scrollto" href="calendario.php">Programar eventos</a></li> -->
          <li><a class="nav-link scrollto" href="logout.php">Cerrar sesión</a></li>

        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header -->


  <?php
  include('config.php');

    $SqlEventos   = ("SELECT * FROM eventoscalendar");
    $resulEventos = mysqli_query($con, $SqlEventos);

  ?>
  <div class="mt-5"></div>

  <div class="container">
    <div class="row">
      <div class="col msjs">
        <?php
          include('msjs.php');
        ?>
      </div>
    </div>

  <div class="row">
    <div class="col-md-12 mb-3">
    <h3 class="text-center" id="title">Calendario</h3>
    </div>
  </div>
  </div>


  <div id="calendar"></div>


  <?php  
    include('modalNuevoEvento.php');
    include('modalUpdateEvento.php');
  ?>


  <script src ="js/jquery-3.0.0.min.js"> </script>
  <script src="js/bootstrap.min.js"></script>

  <script type="text/javascript" src="js/moment.min.js"></script> 
  <script type="text/javascript" src="js/fullcalendar.min.js"></script>

  <script type="text/javascript">

    $(document).ready(function() {
      // Informacion principal
      $("#calendar").fullCalendar({
        header: {
          //left: "prev,next today",
          left: "prev,next",
          center: "title",
          //right: "month,agendaWeek,agendaDay"
          right: "month"
        },

        //locale: 'es',

        defaultView: "month",
        navLinks: true, 
        editable: true,
        eventLimit: true, 
        selectable: true,
        selectHelper: false,

    //Nuevo Evento
    // Se crea una funcion con las fechas de inicio y finalizacion del evento
      select: function(start, end){
          // modal se emplea para generar la ventana de texto flotante
          $("#exampleModal").modal();
          //formato de la fecha de inicio y final
          $("input[name=fecha_inicio]").val(start.format('DD-MM-YYYY'));
          var valorFechaFin = end.format("DD-MM-YYYY");
          var F_final = moment(valorFechaFin, "DD-MM-YYYY").subtract(1, 'days').format('DD-MM-YYYY'); //Le resto 1 dia
          $('input[name=fecha_fin').val(F_final);  

        },
          
        events: [
          <?php
           while($dataEvento = mysqli_fetch_array($resulEventos)){ ?>
              {
              _id: '<?php echo $dataEvento['id']; ?>',
              title: '<?php echo $dataEvento['evento']; ?>',
              start: '<?php echo $dataEvento['fecha_inicio']; ?>',
              end:   '<?php echo $dataEvento['fecha_fin']; ?>',
              color: '<?php echo $dataEvento['color_evento']; ?>'
              },
            <?php } ?>
        ],


    //Eliminar Evento
    eventRender: function(event, element) {
        element
          .find(".fc-content")
          .prepend("<span id='btnCerrar'; class='closeon material-icons'>&#xe5cd;</span>");
        
        //Eliminar evento
        element.find(".closeon").on("click", function() {

      var pregunta = confirm("Deseas Borrar este Evento?");   
      if (pregunta) {

        $("#calendar").fullCalendar("removeEvents", event._id);

         $.ajax({
                type: "POST",
                url: 'deleteEvento.php',
                data: {id:event._id},
                success: function(datos)
                {
                  $(".alert-danger").show();

                  setTimeout(function () {
                    $(".alert-danger").slideUp(500);
                  }, 3000); 

                }
            });
          }
        });
      },


    //Moviendo Evento Drag - Drop
    eventDrop: function (event, delta) {
      var idEvento = event._id;
      var start = (event.start.format('DD-MM-YYYY'));
      var end = (event.end.format("DD-MM-YYYY"));

        $.ajax({
            url: 'drag_drop_evento.php',
            data: 'start=' + start + '&end=' + end + '&idEvento=' + idEvento,
            type: "POST",
            success: function (response) {
             // $("#respuesta").html(response);
            }
        });
    },

    //Modificar Evento del Calendario 
    eventClick:function(event){
        var idEvento = event._id;
        $('input[name=idEvento').val(idEvento);
        $('input[name=evento').val(event.title);
        $('input[name=fecha_inicio').val(event.start.format('DD-MM-YYYY'));
        $('input[name=fecha_fin').val(event.end.format("DD-MM-YYYY"));

        $("#modalUpdateEvento").modal();
      },


      });


    //Oculta mensajes de Notificacion
      setTimeout(function () {
        $(".alert").slideUp(300);
      }, 2000); 


    });

    </script>
  

</body>

</html>